<?php $__env->startSection('content'); ?>
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">
               
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="col-sm-6"><!-- comment -->
                    <form action="<?php echo e(route("config.logotiposave")); ?>" method="POST"  enctype="multipart/form-data"> 
                        <?php if($edit->logotipo): ?>
                        <div class="views-logo d-flex justify-content-center">
                            <img src="<?php echo e($edit->logotipo); ?>" class="img-fluid " rel="file"  />
                        </div>
                        <?php endif; ?>
                         <?php echo csrf_field(); ?>
                        <hr>
                        <div class="input-image ">
                            <label><i class="fa fa-image"></i> Logotipo</label>
                            <input name="cover" type="file" accept="image/*"   placeholder="imagem"/> 
                        </div> 
                        <hr> 
                        <div class="form-group">
                            <button class="btn btn-primary btn-block"  >Salvar</button>   
                        </div>
                    </form>
                </div>
                <div class="col-sm-6">
                    <form action="<?php echo e(route("config.backgroundsave")); ?>" method="POST"  enctype="multipart/form-data"> 
                        <?php if($edit->background): ?>
                        <div class="views-logo d-flex justify-content-center">
                            <img src="<?php echo e($edit->background); ?>" class="img-fluid " rel="file"  />
                        </div>
                        <?php endif; ?>
                         <?php echo csrf_field(); ?>
                        <hr>
                        <div class="input-image ">
                            <label><i class="fa fa-image"></i> Background</label>
                            <input name="cover" type="file" accept="image/*"   placeholder="imagem"/> 
                        </div> 
                        <hr> 
                        <div class="form-group">
                            <button class="btn btn-primary btn-block"  >Salvar</button>   
                        </div> 
                    </form>
                </div>
            </div>

        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lu-ca\sistema-fullcontrol\resources\views/backend/logotipo.blade.php ENDPATH**/ ?>