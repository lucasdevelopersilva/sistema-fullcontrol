<?php $__env->startSection('content'); ?>
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">
                <a href="<?php echo e(route("promocao.index")); ?>" class="btn btn-sm btn-primary" title="Lista"><i class="fa fa-list"></i> LISTA</a>
                <a href="<?php echo e(route("promocao.create")); ?>" class="btn btn-sm btn-primary" title="Nova"><i class="fa fa-plus"></i> NOVA</a>

                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route("promocao.update",['id'=>$edit->id])); ?>" method="POST"  enctype="multipart/form-data"> 
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-4"><!-- comment -->
                        <?php if($edit->cover): ?>
                        <div class="views-logo">
                            <img src="<?php echo e($edit->cover); ?>" class="img-fluid " rel="file"  />
                        </div>
                        <?php endif; ?>
                        <hr>
                        <div class="input-image ">
                            <label><i class="fa fa-image"></i> Imagem de Capa</label>
                            <input name="cover" type="file" accept="image/*"   placeholder="imagem"/> 
                        </div> 
                        <hr> 
                        <div class="form-group">
                            <button class="btn btn-primary btn-block"  >Salvar</button>   
                        </div>
                    </div>
                    <div class="col-sm-8">

                        <?php echo csrf_field(); ?>
                        <div class="form-group"><!-- comment -->
                            <label>Título</label>
                            <input class="form-control" name="title" placeholder="Título da promoção" value="<?php echo e($edit->title); ?>">
                        </div>
                        <div class="form-group "><!-- comment -->
                            <label>Descrição</label>
                            <textarea class="form-control ckeditor" name="description"   ><?php echo e($edit->description); ?></textarea>
                        </div>
                        <div class="form-group"><!-- comment -->
                            <label>Status</label>
                            <input type="checkbox" name="status"  data-bootstrap-switch data-off-color="danger" data-on-color="success" <?php echo e($edit->status==1 ? 'checked' : ''); ?>>
                        </div>



                    </div>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lu-ca\sistema-fullcontrol\resources\views/backend/promocao/edit.blade.php ENDPATH**/ ?>