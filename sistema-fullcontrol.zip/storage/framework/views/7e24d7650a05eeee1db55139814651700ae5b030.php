<?php $__env->startSection('content'); ?>
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">

                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12"><!-- comment -->
                    <form action="<?php echo e(route("app.gerarApk")); ?>" method="POST"  enctype="multipart/form-data"> 
                        <?php echo csrf_field(); ?> 
                        <div class="form-group">
                            <label>Versão </label>
                            <select name="version" class="form-control" type="file" > 
                                <?php for($x=1; $x<=10; $x++): ?> 
                                <?php for($y=0; $y<=9; $y++): ?> 
                                <option value="<?php echo e($x); ?>.<?php echo e($y); ?>"><?php echo e($x); ?>.<?php echo e($y); ?></option>
                                <?php endfor; ?>
                                <?php endfor; ?>
                            </select>
                        </div>


                        <div class="form-group">
                            <button class="btn btn-primary btn-block"  >Gerar</button>   
                        </div>
                    </form>
                </div>                
            </div>

        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lu-ca\sistema-fullcontrol\resources\views/backend/app.blade.php ENDPATH**/ ?>