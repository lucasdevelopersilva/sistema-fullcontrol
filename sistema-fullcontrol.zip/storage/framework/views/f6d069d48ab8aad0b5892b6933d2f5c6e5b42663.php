<?php $__env->startSection('content'); ?>
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">                
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route("config.update")); ?>" method="POST"  enctype="multipart/form-data"> 
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                        <?php endif; ?>
                    </div>                   
                    <div class="col-sm-12">

                        <?php echo csrf_field(); ?>
                        <div class="form-group"><!-- comment -->
                            <label>Nome da Rádio</label>
                            <input class="form-control" name="title" placeholder="Nome" value="<?php echo e($edit->title); ?>">
                        </div>
                       
                        <div class="form-group"><!-- comment -->
                            <label>Site</label>
                            <input class="form-control" name="site" value="<?php echo e($edit->site); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>facebook</label>
                            <input class="form-control"   name="facebook"  value="<?php echo e($edit->facebook); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>Instagram</label>
                            <input class="form-control"   name="instagram"  value="<?php echo e($edit->instagram); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>Twitter</label>
                            <input class="form-control"   name="twitter"  value="<?php echo e($edit->twitter); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>Whatsapp</label>
                            <input class="form-control"   name="whatsapp"  value="<?php echo e($edit->whatsapp); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>Link WebTv</label>
                            <input class="form-control"   name="webtv"  value="<?php echo e($edit->webtv); ?>">
                        </div>                    
                        <div class="form-group"><!-- comment -->
                            <label>Link da rádio</label>
                            <input class="form-control"   name="stream"  value="<?php echo e($edit->stream); ?>">
                        </div>                    
                                       
                         <div class="form-group">
                            <button class="btn btn-primary btn-block"  >Salvar</button>   
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">

        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lu-ca\sistema-fullcontrol\resources\views/backend/config.blade.php ENDPATH**/ ?>