<?php $__env->startSection('content'); ?>
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools"> 
                <a href="<?php echo e(route("users.create")); ?>" class="btn btn-sm btn-primary" title="Nova"><i class="fa fa-plus"></i> NOVA</a>

                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">
            <div class="col-sm-12">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <?php if(count($list)>=1): ?> 
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class=' col-sm-6 col-md-4 col-lg-3 col'>
                    <div class='card'>                        
                        <div class="card-body">
                            <h2 class="cardtitle" ><?php echo e($item->name); ?></h2> 
                        </div>
                         <ul class="list-group-flush list-group">
                                <li class="list-group-item"><?php echo e($item->email); ?></li>
                                <li class="list-group-item"><?php echo e($item->city); ?></li>
                                <li class="list-group-item"><?php echo e($item->state); ?></li>
                                <li class="list-group-item"><?php echo e($item->status); ?></li>
                                <li class="list-group-item"><?php echo e($item->created_at); ?></li>
                            </ul>
                        <div class="card-footer">
                            <a href="<?php echo e(route("users.delete",['id'=>$item->id])); ?>" class="btn btn-sm btn-danger" title="remover"><i class="fa fa-trash"></i></a>
                            <a href="<?php echo e(route("users.save",['id'=>$item->id])); ?>" class="btn btn-sm btn-primary" title="Editar"><i class="far fa-edit"></i></a>
                            <a href="<?php echo e(route("users.loginid",['id'=>$item->id])); ?>" class="btn btn-sm btn-primary" title="Login"><i class="far fa-lock-open"></i> Acessar</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                <div class=' col'>
                    <div class='alert alert-info'>
                        Não existe rádios cadastradas
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
           
        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lu-ca\sistema-fullcontrol\resources\views/backend/users/index.blade.php ENDPATH**/ ?>