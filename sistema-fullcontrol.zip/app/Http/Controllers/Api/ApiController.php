<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ApiController extends Controller {

    private $id;

    public function index($id, $action = "get_MenuApp") {
        header("Content-Type:application/json");
        date_default_timezone_set("America/Sao_paulo");
        $this->id = $id;
        $result = $this->$action();
        return response()->json($result);
   
    }

    public function get_MenuApp() {
        $data = \App\Models\Config::where("user_id", $this->id)->first();
        $data['status'] = 1;
        return [["id" => $data->id,
        "tv_link" => $data['webtv'],
        "tv_status" => ($data['tv_status'] == 1 ? "true" : 'false'),
        "whatsapp_link" => $data->whatsapp,
        "whatsapp_status" => ($data['status'] == 1 ? "true" : 'false'),
        "site_link" => $data->site,
        "site_status" => ($data['status'] == 1 ? "true" : 'false'),
        "facebook_link" => $data->facebook,
        "facebook_status" => ($data['status'] == 1 ? "true" : 'false'),
        "twitter_link" => $data->twitter,
        "twitter_status" => ($data['twitter'] == 1 ? "true" : 'false'),
        "instagram_link" => $data->instagram,
        "instagram_status" => ($data['status'] == 1 ? "true" : 'false'),
        "programacao_status" => ($data['status'] == 1 ? "true" : 'false'),
        "promocao_status" => ($data['status'] == 1 ? "true" : 'false'),
        "noticias_status" => ($data['status'] == 1 ? "true" : 'false'),
        "equipe_status" => ($data['status'] == 1 ? "true" : 'false'),
        "recados_status" => ($data['status'] == 1 ? "true" : 'false'),
        ]];
    }

    public function get_programacao() {
        $data = \App\Models\Programation::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'dia' => $item->day_programe,
                    'programa' => $item->title,
                    'descricao' => $item->description,
                    'img_agenda' => $cover,
                    'inicio' => $item->timestart,
                    'fim' => $item->timeend,
                    'user_id' => $this->id,
                    'status' => $item->status];

            endforeach;
        endif;

        return $retorno;
    }

    public function get_programacao_atual() {
        $data = \App\Models\Programation::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'dia' => $item->day_programe,
                    'programa' => $item->title,
                    'descricao' => $item->description,
                    'img_agenda' => $cover,
                    'inicio' => $item->timestart,
                    'fim' => $item->timeend,
                    'user_id' => $this->id,
                    'status' => $item->status];

            endforeach;
        endif;

        return $retorno;
    }

    public function get_noticias() {
        $data = \App\Models\Posts::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'titulo' => $item->title,
                    'descricao' => $item->description,
                    'imagem' => $cover,
                    'data' => $item->created_at,
                    'user_id' => $this->id,
                    'status' => $item->status];

            endforeach;
        endif;

        return $retorno;
    }

    public function get_equipe() {
        $data = \App\Models\Teams::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'nome' => $item->name,
                    'descricao' => $item->description,
                    'img_equipe' => $cover,
                    'user_id' => $this->id,
                    'status' => $item->status,
                    'facebook' => '',
                    'whatsapp' => '',
                    'instagram' => '',
                ];


            endforeach;
        endif;
        return $retorno;
    }

    public function get_promocoes() {
        $data = \App\Models\Promotion::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'titulo' => $item->title,
                    'descricao' => $item->description,
                    'imagem' => $cover,
                    'user_id' => $this->id,
                    'status' => $item->status,
                ];


            endforeach;
        endif;
        return $retorno;
    }

    public function set_promocao() {
        $data = \App\Models\Promotion::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'titulo' => $item->title,
                    'descricao' => $item->description,
                    'imagem' => $cover,
                    'user_id' => $item->id,
                    'status' => $item->status,
                ];


            endforeach;
        endif;
        return $retorno;
    }

    public function get_mural() {
        $data = \App\Models\Promotion::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'titulo' => $item->title,
                    'descricao' => $item->description,
                    'imagem' => $cover,
                    'user_id' => $item->id,
                    'status' => $item->status,
                ];


            endforeach;
        endif;
        return $retorno;
    }

    public function set_mural() {
        $data = \App\Models\Promotion::where("user_id", $this->id)->paginate(500);
        $retorno = [];
        if (count($data)):
            foreach ($data as $item):

                $cover = url($item->cover);
                $retorno[] = ['id' => $item->id,
                    'titulo' => $item->title,
                    'descricao' => $item->description,
                    'imagem' => $cover,
                    'user_id' => $item->id,
                    'status' => $item->status,
                ];


            endforeach;
        endif;
        return $retorno;
    }

    public function get_config() {
        $data = \App\Models\Config::where("user_id", $this->id)->first();
         $radio_logo = url($data->logotipo);
         $radio_bg = url($data->background);
         
        $retorno['result'][] = [
            'id' => $data->id,
            'capa_background' => true,
            'radio_name' => $data->title,
            'radio_image' => $radio_logo,
            'radio_bg' => $radio_bg,
            'radio_bg_status' => "true",
            'radio_title' => false,
            'radio_url' => $data->stream
            ];

        return $retorno;
    }

}

//@APP_sdk_0990